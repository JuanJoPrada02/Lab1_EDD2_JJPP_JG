import pandas as pd
from arbol import AVLTree  # Asegúrate de que el archivo se llama arbol.py

# ===== Funciones del menú =====
def mostrar_menu():
    print("\n===== MENÚ PRINCIPAL =====")
    print("1. Insertar un nodo")
    print("2. Eliminar un nodo (por métrica)")
    print("3. Buscar un nodo (por métrica)")
    print("4. Búsquedas avanzadas")
    print("5. Mostrar recorrido por niveles (solo ISO3)")
    print("6. Mostrar información de nodos guardados")
    print("7. Salir")

def mostrar_menu_busquedas():
    print("\n--- BÚSQUEDAS AVANZADAS ---")
    print("a. Países con temperatura en un año > promedio mundial en ese año")
    print("b. Países con temperatura en un año < promedio global")
    print("c. Países con media >= valor dado")
    print("d. Volver al menú principal")

# ===== Programa principal =====
if __name__ == "__main__":
    # ===== Cargar dataset =====
    df = pd.read_csv("dataset_climate_change.csv")
    year_cols = [col for col in df.columns if col.startswith("F")]

    records = []
    for _, row in df.iterrows():
        promedio = row[year_cols].mean()
        data = {
            "ObjectId": row["ObjectId"],
            "Country": row["Country"],
            "ISO3": row["ISO3"],
            "temperaturas": {col: row[col] for col in year_cols}
        }
        records.append({"key": promedio, "data": data})

    # ===== Construir árbol =====
    tree = AVLTree()
    root = None
    for rec in records:
        root = tree.insert(root, rec["key"], rec["data"])

    print("Árbol cargado con dataset. ✅")
    tree.visualize_levels(root, "arbol_inicial")

    # ===== Resultados de búsquedas =====
    ultimo_resultado = []

    # ===== Menú interactivo =====
    while True:
        mostrar_menu()
        opcion = input("Selecciona una opción: ").strip()

        # ----- Insertar nodo -----
        if opcion == "1":
            iso = input("ISO3 del país: ").strip()
            try:
                val = float(input("Temperatura media (métrica): ").strip())
            except:
                print("Valor inválido.")
                continue
            data = {"ISO3": iso, "Country": iso, "ObjectId": -1, "temperaturas": {}}
            root = tree.insert(root, val, data)
            tree.visualize_levels(root, "insertar_" + iso, highlight=[iso])

        # ----- Eliminar nodo -----
        elif opcion == "2":
            root = tree.eliminar_por_metrica_interactiva(root)

        # ----- Buscar nodo -----
        elif opcion == "3":
            try:
                val = float(input("Métrica (temperatura media) a buscar: ").strip())
            except:
                print("Valor inválido.")
                continue

            nodo = tree.search(root, val, tol=1e-3)
            if nodo:
                print(f"Nodo encontrado: {nodo.data['ISO3']} con key={nodo.key}")
                ultimo_resultado = [nodo]
                tree.visualize_levels(root, "buscar_" + nodo.data["ISO3"], highlight=[nodo.data["ISO3"]])
            else:
                all_nodes = tree.traverse_and_collect(root, lambda n: True)
                all_nodes.sort(key=lambda n: abs(n.key - val))
                nearest = all_nodes[:5]
                print("\nNo se encontró un nodo exacto.")
                print("Mostrando los 5 nodos más cercanos (ISO3, key):")
                for n in nearest:
                    print(f"{n.data['ISO3']} -> {round(n.key, 4)} (diff={round(abs(n.key - val), 5)})")
                ultimo_resultado = nearest

        # ----- Búsquedas avanzadas -----
        elif opcion == "4":
            while True:
                mostrar_menu_busquedas()
                sub = input("Selecciona una búsqueda: ").strip().lower()
                if sub == "d":
                    break
                # Aquí puedes implementar tus búsquedas avanzadas como antes
                print("Funcionalidad de búsqueda avanzada aún por implementar.")

        # ----- Recorrido por niveles -----
        elif opcion == "5":
            niveles = tree.level_order_recursive(root)
            for i, nivel in enumerate(niveles, start=1):
                print(f"Nivel {i}: {nivel}")
            tree.visualize_levels(root, "recorrido_niveles")

        # ----- Información de nodos guardados -----
        elif opcion == "6":
            if not ultimo_resultado:
                print("No hay nodos guardados de búsquedas previas.")
                continue

            print("\nNodos disponibles:")
            for idx, nodo in enumerate(ultimo_resultado, start=1):
                print(f"{idx}. {nodo.data['ISO3']} (key={round(nodo.key, 4)})")

            try:
                sel = int(input("Selecciona el nodo por índice: "))
                nodo = ultimo_resultado[sel - 1]
            except Exception:
                print("Selección inválida.")
                continue

            print("\n=== Información del nodo seleccionado ===")
            print(f"ISO3: {nodo.data['ISO3']}")
            print(f"País: {nodo.data.get('Country')}")
            print(f"Métrica (temperatura media): {round(nodo.key, 4)}")
            nivel = tree.get_level(root, nodo.key)
            print(f"Nivel en el árbol: {nivel}")
            fb = tree.get_balance(nodo)
            print(f"Factor de balance: {fb}")
            padre = tree.get_parent(root, nodo)
            print(f"Padre: {padre.data['ISO3'] if padre else None}")
            abuelo = tree.get_grandparent(root, nodo)
            print(f"Abuelo: {abuelo.data['ISO3'] if abuelo else None}")
            tio = tree.get_uncle(root, nodo)
            print(f"Tío: {tio.data['ISO3'] if tio else None}")

        # ----- Salir -----
        elif opcion == "7":
            print("Saliendo del programa.")
            break

        else:
            print("Opción inválida.")
