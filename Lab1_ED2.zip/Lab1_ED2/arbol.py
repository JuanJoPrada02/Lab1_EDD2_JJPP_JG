from graphviz import Digraph

class Node:
    def __init__(self, key, data):
        self.key = key
        self.data = data
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:

    # ========== Funciones básicas del AVL ==========
    def get_height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.get_height(node.left) - self.get_height(node.right)

    def right_rotate(self, y):
        x = y.left
        T2 = x.right

        x.right = y
        y.left = T2

        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))
        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))

        return x

    def left_rotate(self, x):
        y = x.right
        T2 = y.left

        y.left = x
        x.right = T2

        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))
        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))

        return y

    def insert(self, root, key, data, do_visualize=False):
        if not root:
            return Node(key, data)
        elif key < root.key:
            root.left = self.insert(root.left, key, data, do_visualize)
        else:
            root.right = self.insert(root.right, key, data, do_visualize)

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        # Rotaciones
        if balance > 1 and key < root.left.key:
            return self.right_rotate(root)
        if balance < -1 and key > root.right.key:
            return self.left_rotate(root)
        if balance > 1 and key > root.left.key:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and key < root.right.key:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, key):
        if not root:
            return root
        elif key < root.key:
            root.left = self.delete(root.left, key)
        elif key > root.key:
            root.right = self.delete(root.right, key)
        else:
            if not root.left:
                return root.right
            elif not root.right:
                return root.left
            temp = self.min_value_node(root.right)
            root.key, root.data = temp.key, temp.data
            root.right = self.delete(root.right, temp.key)

        if not root:
            return root

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        # Rotaciones
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    # ========== Búsqueda aproximada por clave (métrica) ==========
    def search(self, root, key, tol=1e-3):
        """
        Busca un nodo cuya key esté dentro de +/- tol alrededor de 'key'.
        Recorre por BST pero usa comparación aproximada para la igualdad.
        """
        if not root:
            return None
        try:
            # comparación tolerante
            if abs(root.key - key) <= tol:
                return root
        except Exception:
            # si root.key o key no son numéricos
            pass

        if key < root.key:
            return self.search(root.left, key, tol)
        else:
            return self.search(root.right, key, tol)

    # ========== Relaciones ==========
    def get_parent(self, root, node, parent=None):
        if not root:
            return None
        if root == node:
            return parent
        if node.key < root.key:
            return self.get_parent(root.left, node, root)
        else:
            return self.get_parent(root.right, node, root)

    def get_level(self, root, key, level=1):
        if not root:
            return 0
        if abs(root.key - key) <= 1e-9:
            return level
        if key < root.key:
            return self.get_level(root.left, key, level + 1)
        return self.get_level(root.right, key, level + 1)

    def get_grandparent(self, root, node):
        parent = self.get_parent(root, node)
        if parent:
            return self.get_parent(root, parent)
        return None

    def get_uncle(self, root, node):
        parent = self.get_parent(root, node)
        grandparent = self.get_grandparent(root, node)
        if not grandparent:
            return None
        if grandparent.left == parent:
            return grandparent.right
        else:
            return grandparent.left

    # ========== Recorrido por niveles ==========
    def get_height_full(self, node):
        if not node:
            return 0
        return 1 + max(self.get_height_full(node.left), self.get_height_full(node.right))

    def print_level(self, node, level, result):
        if not node:
            return
        if level == 1:
            result.append(node.data["ISO3"])
        elif level > 1:
            self.print_level(node.left, level - 1, result)
            self.print_level(node.right, level - 1, result)

    def level_order_recursive(self, root):
        h = self.get_height_full(root)
        levels = []
        for i in range(1, h + 1):
            current_level = []
            self.print_level(root, i, current_level)
            levels.append(current_level)
        return levels

    # ========== Búsquedas avanzadas ==========
    def traverse_and_collect(self, root, condition):
        if not root:
            return []
        result = []
        if condition(root):
            result.append(root)
        result += self.traverse_and_collect(root.left, condition)
        result += self.traverse_and_collect(root.right, condition)
        return result

    def search_temp_greater_than_year_avg(self, root, df, year):
        year_col = f"F{year}"
        avg = df[year_col].mean()
        return self.traverse_and_collect(root, lambda node: node.data["temperaturas"].get(year_col, 0) > avg)

    def search_temp_less_than_global_avg(self, root, df, year):
        year_col = f"F{year}"
        global_avg = df[[c for c in df.columns if c.startswith("F")]].mean().mean()
        return self.traverse_and_collect(root, lambda node: node.data["temperaturas"].get(year_col, 0) < global_avg)

    def search_mean_greater_equal(self, root, value, sort_desc=False):
        try:
            v = float(value)
        except Exception:
            return []
        nodes = self.traverse_and_collect(root, lambda node: float(node.key) >= v)
        if sort_desc:
            nodes.sort(key=lambda n: float(n.key), reverse=True)
        return nodes

    # ========== Visualizaciones ==========
    def visualize_results(self, nodes, filename="subgrafo_resultados", highlight=None):
        dot = Digraph()
        dot.attr('node', shape='circle', style='filled')

        highlight = highlight or []
        found_ids = {id(n): n for n in nodes}

        for node in nodes:
            label = f"{node.data['ISO3']}\\n{round(node.key, 2)}"
            color = "forestgreen" if node.data["ISO3"] in highlight else "lightgreen"
            dot.node(str(id(node)), label, style="filled", color=color)

            if node.left and id(node.left) in found_ids:
                dot.edge(str(id(node)), str(id(node.left)))
            if node.right and id(node.right) in found_ids:
                dot.edge(str(id(node)), str(id(node.right)))

        dot.render(filename, format="png", cleanup=True)
        print(f"Subgrafo generado: {filename}.png ✅")

    def visualize_levels(self, root, filename="niveles_arbol", highlight=None):
        levels = self.level_order_recursive(root)
        dot = Digraph()
        dot.attr(rankdir="TB")

        highlight = highlight or []

        # Para cada ISO3 en los niveles, buscamos su nodo y mostramos ISO3 + métrica
        for i, level in enumerate(levels, start=1):
            for iso in level:
                # encontrar el nodo con dicho ISO3 (traverse_and_collect lo encuentra)
                nodes_iso = self.traverse_and_collect(root, lambda x: x.data["ISO3"] == iso)
                node = nodes_iso[0] if nodes_iso else None
                label = iso if not node else f"{iso}\\n{round(node.key, 2)}"
                color = "forestgreen" if iso in highlight else "lightblue"
                dot.node(f"{iso}", label, shape="circle", style="filled", color=color)

        # Asegurar niveles en la misma fila
        for i, level in enumerate(levels, start=1):
            with dot.subgraph() as s:
                s.attr(rank="same")
                for iso in level:
                    s.node(iso)

        # Añadir aristas padre -> hijo
        def add_edges(node):
            if not node:
                return
            if node.left:
                dot.edge(node.data["ISO3"], node.left.data["ISO3"])
                add_edges(node.left)
            if node.right:
                dot.edge(node.data["ISO3"], node.right.data["ISO3"])
                add_edges(node.right)

        add_edges(root)

        dot.render(filename, format="png", cleanup=True)
        print(f"Imagen de recorrido por niveles generada: {filename}.png ✅")
