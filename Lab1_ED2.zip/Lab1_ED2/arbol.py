from graphviz import Digraph

# ===== Nodo del árbol =====
class Node:
    def __init__(self, key, data):
        self.key = key
        self.data = data
        self.left = None
        self.right = None
        self.height = 1

# ===== Árbol AVL completo =====
class AVLTree:
    def __init__(self):
        self.rotated_nodes = set()  # nodos rotados en la última operación

    # ===== Altura y balance =====
    def get_height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.get_height(node.left) - self.get_height(node.right)

    # ===== Rotaciones =====
    def right_rotate(self, y):
        x = y.left
        T2 = x.right

        x.right = y
        y.left = T2

        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))
        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))

        self.rotated_nodes.add(id(y))
        self.rotated_nodes.add(id(x))

        return x

    def left_rotate(self, x):
        y = x.right
        T2 = y.left

        y.left = x
        x.right = T2

        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))
        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))

        self.rotated_nodes.add(id(x))
        self.rotated_nodes.add(id(y))

        return y

    # ===== Buscar nodo por ISO3 =====
    def search_by_iso(self, root, iso):
        if not root:
            return None
        if root.data["ISO3"] == iso:
            return root
        left_search = self.search_by_iso(root.left, iso)
        if left_search:
            return left_search
        return self.search_by_iso(root.right, iso)

    # ===== Insertar nodo sin duplicados =====
    def insert(self, root, key, data):
        self.rotated_nodes.clear()

        if self.search_by_iso(root, data["ISO3"]):
            print(f"Nodo con ISO3={data['ISO3']} ya existe. No se insertará.")
            return root

        if not root:
            return Node(key, data)
        elif key < root.key:
            root.left = self.insert(root.left, key, data)
        else:
            root.right = self.insert(root.right, key, data)

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and key < root.left.key:
            return self.right_rotate(root)
        if balance < -1 and key > root.right.key:
            return self.left_rotate(root)
        if balance > 1 and key > root.left.key:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and key < root.right.key:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    # ===== Eliminar nodo por clave =====
    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, key):
        self.rotated_nodes.clear()

        if not root:
            return root
        elif key < root.key:
            root.left = self.delete(root.left, key)
        elif key > root.key:
            root.right = self.delete(root.right, key)
        else:
            # Nodo encontrado
            if not root.left:
                return root.right
            elif not root.right:
                return root.left
            temp = self.min_value_node(root.right)
            root.key, root.data = temp.key, temp.data
            root.right = self.delete(root.right, temp.key)

        if not root:
            return root

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    # ===== Eliminación interactiva por métrica =====
    def eliminar_por_metrica_interactiva(self, root):
        try:
            val = float(input("Ingresa la métrica (temperatura media) a eliminar: ").strip())
        except:
            print("Valor inválido.")
            return root

        all_nodes = self.traverse_and_collect(root, lambda n: True)
        all_nodes.sort(key=lambda n: abs(n.key - val))
        nearest = all_nodes[:10]

        if not nearest:
            print("No se encontraron nodos cercanos a la métrica ingresada.")
            return root

        print("Nodos más cercanos a la métrica ingresada:")
        for i, n in enumerate(nearest, start=1):
            print(f"{i}. ISO3: {n.data['ISO3']}, Métrica: {n.key}")

        try:
            sel = int(input("Selecciona el nodo a eliminar por índice: "))
            nodo_a_eliminar = nearest[sel - 1]
        except:
            print("Selección inválida.")
            return root

        root = self.delete(root, nodo_a_eliminar.key)
        print(f"Nodo {nodo_a_eliminar.data['ISO3']} eliminado ✅")
        self.visualize_levels(root, "eliminar_seleccionado", highlight=[nodo_a_eliminar.data["ISO3"]])
        return root

    # ===== Buscar nodo por clave =====
    def search(self, root, key, tol=1e-3):
        if not root:
            return None
        if abs(root.key - key) <= tol:
            return root
        if key < root.key:
            return self.search(root.left, key, tol)
        else:
            return self.search(root.right, key, tol)

    # ===== Recorrido por niveles =====
    def level_order_recursive(self, root):
        levels = []
        def recorrer(node, nivel):
            if not node:
                return
            if len(levels) == nivel:
                levels.append([])
            levels[nivel].append(node.data["ISO3"])
            recorrer(node.left, nivel + 1)
            recorrer(node.right, nivel + 1)
        recorrer(root, 0)
        return levels

    # ===== Visualización por niveles con colores =====
    def visualize_levels(self, root, filename="niveles_arbol", highlight=None):
        levels = self.level_order_recursive(root)
        dot = Digraph()
        dot.attr(rankdir="TB")
        highlight = highlight or []

        for i, level in enumerate(levels, start=1):
            for iso in level:
                nodes_iso = self.traverse_and_collect(root, lambda x: x.data["ISO3"] == iso)
                node = nodes_iso[0] if nodes_iso else None
                label = iso if not node else f"{iso}\\n{round(node.key,2)}"

                if node and id(node) in self.rotated_nodes:
                    color = "yellow"
                elif iso in highlight:
                    color = "forestgreen"
                else:
                    color = "lightblue"

                dot.node(f"{iso}", label, shape="circle", style="filled", color=color)

        for i, level in enumerate(levels, start=1):
            with dot.subgraph() as s:
                s.attr(rank="same")
                for iso in level:
                    s.node(iso)

        def add_edges(node):
            if not node:
                return
            if node.left:
                dot.edge(node.data["ISO3"], node.left.data["ISO3"])
                add_edges(node.left)
            if node.right:
                dot.edge(node.data["ISO3"], node.right.data["ISO3"])
                add_edges(node.right)

        add_edges(root)
        dot.render(filename, format="png", cleanup=True)
        print(f"Imagen generada: {filename}.png ✅")
        self.rotated_nodes.clear()

    # ===== Función para recorrer y recolectar nodos según condición =====
    def traverse_and_collect(self, root, condition):
        if not root:
            return []
        result = []
        if condition(root):
            result.append(root)
        result += self.traverse_and_collect(root.left, condition)
        result += self.traverse_and_collect(root.right, condition)
        return result

    # ===== Métodos auxiliares =====
    def get_level(self, root, key, nivel=1):
        if not root:
            return None
        if root.key == key:
            return nivel
        res = self.get_level(root.left, key, nivel+1)
        if res:
            return res
        return self.get_level(root.right, key, nivel+1)

    def get_parent(self, root, node, parent=None):
        if not root:
            return None
        if root == node:
            return parent
        left = self.get_parent(root.left, node, root)
        if left:
            return left
        return self.get_parent(root.right, node, root)

    def get_grandparent(self, root, node):
        parent = self.get_parent(root, node)
        if parent:
            return self.get_parent(root, parent)
        return None

    def get_uncle(self, root, node):
        parent = self.get_parent(root, node)
        grandparent = self.get_grandparent(root, node)
        if grandparent:
            if grandparent.left == parent:
                return grandparent.right
            else:
                return grandparent.left
        return None
